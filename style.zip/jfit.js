// Function to dynamically show the category based on the clicked link
function showCategory(category) {
    const productDisplay = document.getElementById('product-display');
    productDisplay.innerHTML = ''; // Clear previous content

    let products = [];
    
    // Define products for each category
    if (category === 'necklaces') {
        products = [
            { name: '', img: 'https://www.griiham.in/cdn/shop/files/Gold-Pated-Classic-temple-Necklace-set-Necklace-Set-Griiham.jpg?v=1724862245' },
            { name: '', img: 'https://www.griiham.in/cdn/shop/files/Premium-gold-finish-Long-Hara-Necklace-Set-with-AD-Stones-16864N-Necklace-Set-Griiham.jpg?v=1718430116&width=600' },
            { name: '', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSc1gPqV9TlawPmA4rRS4oT-46sDJ-YpwscPCjgBB6FhxBj_x9jg4XTfUB_nogQH7-hknE&usqp=CAU' },
            { name: '', img: 'https://i.pinimg.com/736x/ac/30/7a/ac307a884ade0d1018e07ac7068ba6d0.jpg' },
            { name: '', img: 'https://i.etsystatic.com/19653725/r/il/727090/5041205167/il_570xN.5041205167_ird5.jpg' },
            { name: '', img: 'https://images.meesho.com/images/products/192565747/pxwkr_512.jpg' }
        ];
    } else if (category === 'earrings') {
        products = [
            { name: '', img: 'https://rukminim2.flixcart.com/image/850/1000/xif0q/earring/k/y/y/na-s2-moti-tops-black-monkdecor-original-imagkc7dygxfuhhx.jpeg?q=90&crop=false' },
            { name: '', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfNSc3eVUxrx2etaYF6FxKx01Sk21725HdGw&s' },
            { name: '', img: 'https://assets.ajio.com/medias/sys_master/root/20240701/YXSK/66826dcb1d763220fa8e7b97/-1117Wx1400H-464542919-rosegold-MODEL5.jpg' },
            { name: '', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxqmEp5EwOW3yLgn-DIwBJcc2BA72_2IiC2AGcIhvz0JxXHtUItr8w9LTRmHvY_Ln6kK0&usqp=CAU' },
            { name: '', img: 'https://d25g9z9s77rn4i.cloudfront.net/uploads/product/1128/1661258186_3fa3cb055e7df9468d35.png' },
            { name: '', img: 'https://assets.ajio.com/medias/sys_master/root/20240627/6Gwx/667daa476f60443f31d4833c/-473Wx593H-465226451-beige-MODEL.jpg' }
        ];
    } else if (category === 'bracelets') {
        products = [
            { name: '', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSz7vzIskaI9iU0uVb5mCSG9Itczj3j3twqbD1gkNTq_ByuHuRQZBFkLfaluLhkR8JSkUQ&usqp=CAU' },
            { name: '', img: 'https://images-cdn.ubuy.co.in/6597c6635f2b521b6b00454d-5pcs-fashion-crystal-bracelets-sets-for.jpg' },
            { name: '', img: 'https://5.imimg.com/data5/SELLER/Default/2021/3/OJ/YR/OP/16075677/motiwhitebracelet.jpg' },
            { name: '', img: 'https://www.giva.co/cdn/shop/files/BR044_2.jpg?v=1713249159&width=1946' }
        ];
    } else if (category === 'bridal jewellary set') {
        products = [
            { name: '', img: 'https://blingbag.co.in/cdn/shop/files/IvoryMriyaniBridalJewellerySet_1.jpg?v=1729164074' },
            { name: '', img: 'https://5.imimg.com/data5/SELLER/Default/2023/5/310482872/ZK/ED/RW/14629741/whatsapp-image-2023-05-24-at-12-18-51.jpeg' },
            { name: '', img: 'https://5.imimg.com/data5/ANDROID/Default/2023/3/291732052/CO/MP/LB/106849112/product-jpeg-500x500.jpg' },
            { name: '', img: 'https://images.meesho.com/images/products/392489597/itoiw_512.webp'}
        ];
    } else if (category === 'sider jewellary set') {
        products = [
            { name: '', img: 'https://blingbag.co.in/cdn/shop/files/MulticolorItkariJewellerySet_5.jpg?v=1708503891' },
            { name: '', img: 'https://glitstudio.in/cdn/shop/files/SRHJN108GRY_0136f223-8c82-4f50-b79a-5eb40e3e770e.jpg?v=1719223209' },
            { name: '', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_JhDrTLeHx5wiJNHccw0_kPmf8zJrX4594BADZll-BzHa8IMbwUUUNegKIYdUBd5a5pY&usqp=CAU' },
            { name: '', img: 'https://5.imimg.com/data5/ECOM/Default/2022/9/DK/BX/DU/77950844/zevar-jewelry-high-quality-kundan-bridal-elegant-long-bridal-jewellery-set-by-zevar-38930669371625.jpg' }
        ];
    }  else if (category === 'rings') {
        products = [
            { name: '', img: 'https://images-cdn.ubuy.co.in/633bc8e3524dbd2321535c83-2pcs-rose-diamond-ring-white-zircon.jpg' },
            { name: '', img: 'https://www.candere.com/media/jewellery/images/C004016__1.jpeg' }
        ];
    }else if (category === 'brooches and pin') {
        products = [
            { name: '', img: 'https://rukminim2.flixcart.com/image/850/1000/xif0q/brooch/h/w/r/brooch-flower-fashion-crystal-rhinestone-brooch-for-women-girl-original-imagwgxygszkkwmk.jpeg?q=20&crop=false' },
            { name: '', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKA0chzrMwhwse1QBCdL9xrSIWv5tfK14C8w&s' },
            { name: '', img: 'https://m.media-amazon.com/images/I/51ImdY6h+6L._AC_UY1100_.jpg' },
            { name: '', img: 'https://cf.ltkcdn.net/jewelry/images/std/316181-540x332-brooch-and-pin.jpg' }
        ];
    }else if (category === 'anklets') {
        products = [
            { name: '', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8dK6f8s3qJUPVeYDB9y3_35BbvBklbIC7-w&s' },
            { name: '', img: 'https://cdn0.weddingwire.in/article/5941/original/1280/jpg/31495-bridal-aklets-vinay-goyal-photography-giant-gems.jpeg' },
            { name: '', img: 'https://i.pinimg.com/originals/c9/a9/6e/c9a96e468a86db36b33fdb3e9d4ed192.jpg' },
            { name: '', img: 'https://i.pinimg.com/736x/fa/1b/0a/fa1b0a7a58b7ab13bd85c3b8d62332d4.jpg' },
            { name: '', img: 'https://jaihoindiastore.com/cdn/shop/files/71Rle5ghDdL._SY575.jpg?v=1713594545' },
            { name: '', img: 'https://images.shaadisaga.com/shaadisaga_production/photos/pictures/001/692/835/new_medium/zohaibali.co.uk.jpg' }
        ];
    }  
    

    // Dynamically generate HTML content based on the selected category
    products.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product-category');
        productDiv.innerHTML = `
            <h3>${product.name}</h3>
            <img src="${product.img}" alt="${product.name}">
            <hr>
        `;
        productDisplay.appendChild(productDiv);
    });
}
