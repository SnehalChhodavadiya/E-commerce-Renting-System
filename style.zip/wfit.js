// Function to dynamically show the category based on the clicked link
function showCategory(category) {
    const productDisplay = document.getElementById('product-display');
    productDisplay.innerHTML = ''; // Clear previous content

    let products = [];
    
    // Define products for each category
    if (category === 'Dress') {
        products = [
            { name: 'patiyala dress', img: 'https://paridhancouture.com/cdn/shop/products/27__24108.1650916508.1280.1280__26348.png?v=1734380112' },
            { name: 'sherara dress', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvLdxspeprWe77eyiJPxabZECt31jQp2Z8wQ&s' },
            { name: 'patticoat dress', img: 'https://di2ponv0v5otw.cloudfront.net/posts/2023/06/09/648376932fbf1af6230da570/m_648377905d686b7f4d43bb2b.jpg' },
            { name: 'kurti', img: 'https://www.suratfabric.com/wp-content/uploads/2024/07/Kalaroop-Kriti-by-Kajree-VIscose-Kurti-Catalog-6-Pcs-5.jpeg' },
            { name: 'tunic', img: 'https://assets.ajio.com/medias/sys_master/root/20240728/0bvn/66a5ef1a1d763220fa4553e1/-473Wx593H-464974486-green-MODEL.jpg' },
            { name: 'churidar salvar', img: 'https://i.pinimg.com/originals/72/86/4f/72864f18b69b730c7c3158f58b01f784.jpg' },
            { name: 'Anarkali salwar suit', img: 'https://subhvastra.in/cdn/shop/files/photo_2023-09-09_12-34-44_600x.jpg?v=1703934670' }
        ];
    } else if (category === 'Traditional Wear') {
        products = [
            { name: 'Traditional Kurti', img: 'https://images.meesho.com/images/products/416438872/fqgom_512.webp' },
            { name: 'kediyu', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7zHVYLlCMu7p8oD8PdaI47GkphRb-gND35CbPZ2cHJmH0BaPqRWKBmr3JOEIhJZseXL4&usqp=CAU' },
            { name: 'Indo-western', img: 'https://medias.utsavfashion.com/media/catalog/product/cache/1/small_image/295x/040ec09b1e35df139433887a97daa66f/d/i/digital-printed-georgette-crop-top-set-in-mustard-v1-tqh8.jpg' },
            { name: 'tranding', img: 'https://cdn.shopify.com/s/files/1/0424/1876/5977/files/kurti-with-palazzo-pants_480x480.jpg?v=1665581110' }
        ];
    } 
    else if (category === 'Choli') {
        products = [
            { name: 'bridal choli', img: 'https://dollyjstudio.com/cdn/shop/files/1449_0_600x.jpg?v=1729331121' },
            { name: 'lehenga choli', img: 'https://www.anantexports.in/cdn/shop/files/IMG-20240403_173334.jpg?v=1712146061&width=1946' },
            { name: 'chaniya choli', img: 'https://cygnusfashion.com/cdn/shop/products/photo_2022-05-31_14-48-48.jpg?v=1654003372' },
            { name: 'gamthi choli', img: 'https://empress-clothing.com/cdn/shop/files/9F14.jpg?v=1720855086'}
        ];
    }else if (category === 'Saree') {
        products = [
            { name: 'ajarakh', img: 'https://assets.ajio.com/medias/sys_master/root/20230911/exaP/64fe6b15afa4cf41f5d58acf/-473Wx593H-466548576-coffee-MODEL.jpg' },
            { name: 'banthani', img: 'https://www.aachho.com/cdn/shop/files/NRN_5337.jpg_1_400x.jpg?v=1728302875' },
            { name: 'patolu', img: 'https://assets.ajio.com/medias/sys_master/root/20230823/cIxG/64e5ae84afa4cf41f56f8594/-473Wx593H-466338737-blue-MODEL.jpg' },
            { name: 'handwork sari', img: 'https://medias.utsavfashion.com/media/catalog/product/cache/1/image/500x/040ec09b1e35df139433887a97daa66f/w/o/woven-viscose-organza-scalloped-saree-in-dusty-blue-v1-svca131.jpg' },
            { name: 'banarasi', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMTe9MXlhZye46OqUJ7VWusi2PEE1kCUmrJ3nSPHLWzQCtw0PqRdxKXay9xYUfMh3gfq0&usqp=CAU' },
            { name: 'silk', img: 'https://www.karagiri.com/cdn/shop/files/KINKHAB-1205-1.jpg?v=1711452218' },
            { name: 'batik', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHUlpcDFqXV1BsmGfBd4l4OOMW8qoMFPaQew&s' }
        ];
    } else if (category === 'Full wear') {
        products = [
            { name: 'suit', img: 'https://kw.sacoorbrothers.com/cdn/shop/files/86d1770f2d686651ffa0df49a85a7bee_df572339-b8be-4d7d-ae28-19ebcfbc999e.jpg?crop=region&crop_height=1800&crop_left=0&crop_top=0&crop_width=1440&v=1712032526&width=1440' },
            { name: '3 piece suit', img: 'https://www.joshindia.com/cdn/shop/files/Lucaya1101a.jpg?v=1707901062' },
            { name: 'one piece', img: 'https://5.imimg.com/data5/ANDROID/Default/2023/5/306098827/RU/BN/ZN/159431556/product-jpeg.jpg' },
            { name: 'skirt', img: 'https://assets.ajio.com/medias/sys_master/root/20231124/kIwB/655fb286afa4cf41f59b9afc/-473Wx593H-466822459-cream-MODEL.jpg'},
            { name: 'jumpsuit', img: 'https://www.libas.in/cdn/shop/files/35098.jpg?v=1736769027' }, 
            { name: 'dangari', img: 'https://rukminim2.flixcart.com/image/550/650/xif0q/dungaree-romper/r/l/b/36-adn-14255-athena-original-imagxc3zhgyjv8rf.jpeg?q=90&crop=false' },
            { name: 'long gown', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQM0KB17YZxVTyizzXNTw7UClb8mfm_B6EVimh7eztoXFL3wUWCiCU48zkuWShL64jX4QA&usqp=CAU' },
            { name: 'short gown', img: 'https://i.pinimg.com/736x/73/b0/0f/73b00fdb14cf384840bfbabf9d292400.jpg' },       ];
    } else if (category === 'Navratri collection') {
        products = [
            { name: 'Classic Koti', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjRP-NSRjBQkf7ShJZpaT0sIXZ8wPfiyKT9w&s' },
            { name: 'gamthi', img: 'https://mahezon.in/cdn/shop/files/Women_s-Traditional-Black-Navratri-Lehenga-Choli-Dupatta-Set-mahezon-47242815_1200x1200.jpg?v=1720019860' },
            { name: 'trendy', img: 'https://www.buyon.in/wp-content/uploads/2023/11/NewLaterstSkyChaniyaCholiforWomenWearNavratriCollection2359_2.webp' },
            { name: 'Traditional', img: 'https://www.anantexports.in/cdn/shop/files/White-and_Deep_Green_Embroidered_Kedia_with_yellow_Tulip_Pant_Traditional_Navratri_Wear_Garba_Dress_for_Women-6_990x.jpg?v=1723059290' }
        ];
    }    

    
    // Dynamically generate HTML content based on the selected category
    products.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product-category');
        productDiv.innerHTML = `
            <h3>${product.name}</h3>
            <img src="${product.img}" alt="${product.name}">
            <hr>
        `;
        productDisplay.appendChild(productDiv);
    });
}
