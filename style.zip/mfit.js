// Function to dynamically show the category based on the clicked link
function showCategory(category) {
    const productDisplay = document.getElementById('product-display');
    productDisplay.innerHTML = ''; // Clear previous content

    let products = [];
    
    // Define products for each category
    if (category === 'blazers') {
        products = [
            { name: 'Formal Blazer', img: 'https://images-cdn.ubuy.co.in/667f7853d371092b4e666b96-coofandy-men-39-s-casual-knit-blazer.jpg' },
            { name: 'Casual Blazer', img: 'https://5.imimg.com/data5/YA/QF/MY-19062938/casual-blazer.jpg' },
            { name: 'party Blazer', img: 'https://4.imimg.com/data4/TA/GK/MY-25044844/blazers-5-500x500.jpg' },
            { name: 'casual Blazer', img: 'https://blackberrys.com/cdn/shop/files/check-casual-blazer-in-olive-aber-blackberrys-clothing-1_900x900.jpg?v=1685951953' }
        ];
    } else if (category === 'kurta') {
        products = [
            { name: 'Traditional Kurta', img: 'https://www.fabfunda.com/product-img/mens-wear-multi-color-pure-mas-1718973755.jpeg' },
            { name: 'Modern Kurta', img: 'https://i.pinimg.com/736x/ac/25/ce/ac25ce9f479a3565690b6c9a69d45b7e.jpg' },
            { name: 'Navaratri Kurta', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTcsb-ywPKNymtMoQYhnrB-48cT0U0qEqfNgQ&s' },
            { name: 'WEDDING Kurta', img: 'https://www.raworiya.com/wp-content/uploads/2024/06/Tulip-Pink-Wedding-Kurta-for-Men.webp' }
        ];
    } else if (category === 'formals') {
        products = [
            { name: 'Office Formal', img: 'https://cdn.shopify.com/s/files/1/0266/6276/4597/files/formal_shirts_for_men_fd416529-4692-4c64-810a-eb1d156088fc.jpg?v=1677785242' },
            { name: 'Luxury Formal', img: 'https://ae-pic-a1.aliexpress-media.com/kf/S709912ee0ed445a48dbb26f6d9fb7a82b/Designer-Men-Suits-For-Wedding-Tuxedo-Silk-Satin-2-Pieces-Blazer-Pants-Double-Breasted-Formal-Prom.jpg_640x640Q90.jpg_.webp' },
            { name: 'Fest Formal', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_V3RTJ6WA8gvkuYLF5qZ--gzZALCZUixXsA&s' },
            { name: 'Luxury Formal', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgtAuD1GvUfAnE7WwkWsamHzymvbVq5TrV6g&s' }
        ];
    } else if (category === 'pathani') {
        products = [
            { name: 'Pathani 1', img: 'https://in.kamakhyaa.com/cdn/shop/products/NYMK01DD-MP01A4.jpg?v=1705653241' },
            { name: 'Pathani 2', img: 'https://cdn.shopaccino.com/qarot/products/184a0942-484280_l.jpg?v=523' },
            { name: 'Pathani 3', img: 'https://img2.ogaanindia.com/pub/media/catalog/product/cache/3f6619daccdb194398d06464ab49fa6e/m/s/ms152ckpb1.jpg' },
            { name: 'Pathani 4', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ50YvgIcKI3kgg3vlYHMM6Ezja3LyqA69QBg&s'}
        ];
    } else if (category === 'koti') {
        products = [
            { name: 'Classic Koti', img: 'https://i.pinimg.com/originals/73/72/63/7372634cb40b9386e7b7a3ebcc305eec.jpg' },
            { name: 'Traditional Koti', img: 'https://www.mangaldeep.co.in/image/cache/data/art-silk-men-s-indowestern-with-sequins-embroidery-work-long-jacket-set-56400-800x1100.jpg' },
            { name: 'Traditional Koti', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpmugdJ5vcw4mLVWRjBRzmdAodAPGrPdaaHA&s' },
            { name: 'Traditional Koti', img: 'https://i.etsystatic.com/45315658/r/il/1242b5/5121243006/il_570xN.5121243006_6wah.jpg' }
        ];
    }  else if (category === 'suit') {
        products = [
            { name: 'Classic suit', img: 'koti1.jpg' },
            { name: 'Traditional suit', img: 'koti2.jpg' }
        ];
    }else if (category === 'shirt') {
        products = [
            { name: 'Classic shirt', img: 'koti1.jpg' },
            { name: 'Traditional shirt', img: 'koti2.jpg' }
        ];
    }else if (category === 'Jodhpuri') {
        products = [
            { name: 'Classic jodhpuri', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpF8g73ydlZGyIFStiwYmGODIYZw7rUgm6tw0sNwPlj5Gq1KiYwFM2FgtlSMVfd3n_ttI&usqp=CAU' },
            { name: 'Traditional jodhpuri', img: 'https://i.etsystatic.com/18307082/r/il/0c81e6/4377495520/il_570xN.4377495520_1pxf.jpg' },
            { name: 'Trading jodhpuri', img: 'https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/27550848/2024/10/9/374b16c2-172c-43f4-9d8b-d09f8759eda01728461099816-Kisah-Men-Kurta-Trousers--Jodhpuri-Bandhgala-Blazer-Set-3491-1.jpg' },
            { name: ' jodhpuri', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKHpP8FWSttvn1F6mwoyxtiiLOe3t57WIz-A&s' }
        ];
    }else if (category === 'Sherwani') {
        products = [
            { name: 'Sherwani 1', img: 'https://img.perniaspopupshop.com/catalog/product/n/k/NKGCM082306_4.jpg?impolicy=detailimageprods' },
            { name: 'Sherwani 2', img: 'https://img.perniaspopupshop.com/catalog/product/y/a/YAJC0922121_1.jpg?impolicy=detailimageprod' },
            { name: 'Sherwani 3', img: 'https://3.imimg.com/data3/KD/RE/MY-8786109/sherwanis.jpg' },
            { name: 'Sherwani 4', img: 'https://shreeman.in/cdn/shop/files/14_48b12030-cc24-44d0-ae5c-6593cd0c8fc3.jpg?v=1712055605&width=700' },
        ];
    }  
    

    // Dynamically generate HTML content based on the selected category
    products.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product-category');
        productDiv.innerHTML = `
            <h3>${product.name}</h3>
            <img src="${product.img}" alt="${product.name}">
            <hr>
        `;
        productDisplay.appendChild(productDiv);
    });
}
